APK बनाने के चरण (Windows PC)
1. Android Studio इंस्टॉल करें (developer.android.com/studio) और एक बार खोलकर SDK का सेटअप पूरा होने दें।
2. इस ज़िप को Extract करें -> Android Studio में "Open" दबाएँ -> अंदर का  android  फ़ोल्डर चुनें -> OK।
3. नीचे "Gradle sync" पूरा होने दें (पहली बार इंटरनेट चाहिए, 5-15 मिनट लग सकते हैं)।
4. ऊपर मेनू: Build -> Build Bundle(s) / APK(s) -> Build APK(s)।
5. नीचे "locate" पर क्लिक करें; फ़ाइल:  android\app\build\outputs\apk\debug\app-debug.apk
6. APK फ़ोन में कॉपी करके खोलें -> "अज्ञात स्रोत से इंस्टॉल" की अनुमति दें -> Install।
PDF सेव होने पर फ़ोन के Documents\Form16 फ़ोल्डर में जाता है और शेयर-विंडो खुलती है।
