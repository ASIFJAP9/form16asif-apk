package com.form16.tds;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
